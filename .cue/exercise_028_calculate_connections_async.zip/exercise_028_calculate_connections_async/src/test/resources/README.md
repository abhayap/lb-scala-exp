calculate_connections_async

# Exercise > Calculate connections asynchronously and parallelized

- In this exercise, you will implement an version of the `connections`
  method that has the following properties:
  
  - It should perform the calculation asynchronously. Hence it will
    return a `Future[Set[Seq[Hop]]]`
  - It should, when present, exploit parallelism of the underlying
    compute infrastructure
    
**Step** **by** **step** **instructions**

- Start from a copy of the non-tail recursive version of the 
  `connections` method
- Rename the method to `connectionsAsync` and define it to return
  an instance of `Future[Set[Seq[Hop]]]`
- What other change needs to be applied to the `connections` method
  parameter list[s] in order to enable to utilisation of `Future`s?
- Adapt the inner `connections` method to take a single argument `soFarF` 
  of type `Future[Vector[Hop]]` and that returns a `Future[Set[Vector[Hop]]]`

- Start by adapting the code to do the first call to the inner
  `connections` method:
  
     `nextHops flatMap (hop => connections(Vector(hop)))`
     
- Apply the "let-the-types-guide-you" principle:
  - Look at the type of the elements you have and the type of what
    you need to produce
  - You will run into the situation where the nested types are
    "in the wrong order"

**Hints**:
  - `Future.sequence` will certainly be part of the solution
  - Also consider applying `map` or `flatMap`

- If you manage to adapt the code for the first call to the inner
  `connections` method, you should be able to adapt the code in
  the inner method using the same principles
- You may need one extra step in the inner method to account for the
  fact that a `Future` is passed as an argument instead of a 
  concrete value
  
- Use the `test` command to verify the solution works as expected

- Use the `nextExercise` command to move to the next exercise.
