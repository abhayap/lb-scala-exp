calculate-connections-II

# Exercise > Calculate connections II

- Next add an immutable `departureTimes` field to `Train`:

  - Use an immutable `Map` of `Station` and `Time` for the type
  - Initialize it with all `Station`s mapped to the according `Time`s

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.