custom-control-abstractions

# Exercise > Custom control abstractions

- Create a new singleton object `Loop` in package `misc` in which
  you will create two new custom loop constructs

- **Attention**: Don't use Scala's `while` for the following

- **Hint**: think recursion while solving this exercise

- Create a `repeatWhile` loop which can be used like this:

```scala
     var x = 0
     repeatWhile(x < 5) {
       println(x)
       x += 1
     }
```

- Create a `repeat-until` loop:

```scala
     var x = 0
     repeat {
       println(x)
       x += 1
     } until(x >= 5)
```

- **Hint**: for the implementation of the `repeat-until` loop you
        should consider using an anonymous class to host one
        of the methods you will have to write 

- Use the `nextExercise` command to move to the next exercise.