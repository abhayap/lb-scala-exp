/*
 * Copyright © 2012 - 2017 Lightbend, Inc. All rights reserved.
 */

package com.lightbend.training.scalatrain

import TestData._
import java.lang.{ IllegalArgumentException => IAE }
import org.scalatest.{ Matchers, WordSpec }

class HopSpec extends WordSpec with Matchers {

  "Creating a Hop" should {
    "throw an IllegalArgumentException for equal from and to" in {
      an[IAE] should be thrownBy Hop.createHop(munich, munich, green)
    }
    "throw an IllegalArgumentException for from and to not back-to-back stations of train" in {
      an[IAE] should be thrownBy Hop.createHop(munich, stuttgart, green)
    }
  }

  "departureTime" should {
    "be initialized correctly" in {
      Hop.createHop(dusseldorf, frankfurt, blue).departureTime shouldEqual blueDusseldorfTime
    }
  }

  "arrivalTime" should {
    "be initialized correctly" in {
      Hop.createHop(dusseldorf, frankfurt, blue).arrivalTime shouldEqual blueFrankfurtTime
    }
  }
}
