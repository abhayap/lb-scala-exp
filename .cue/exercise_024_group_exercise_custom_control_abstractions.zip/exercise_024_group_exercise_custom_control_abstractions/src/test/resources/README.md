group-exercise-custom-control-abstractions

# Exercise > Group Exercise - Custom control abstractions

- Let's create a custom control abstraction for automated resource management
  (ARM)

- A resource is "something that can be closed"

- The "new keyword" `withResource` shall close the given resource automatically

- Usage example:

```scala
     scala> withResource(in) { resource =>
          |   Source.fromInputStream(resource).getLines.size
          | }
     res0: Int = 10
```

- Tip: an InputStream can be created from a file `README.md` as follows:

```
import scala.io.Source
import java.nio.file.Files.newInputStream
import java.nio.file.Paths

val in = newInputStream(Paths.get("README.md"))
```

- Implement `withResource` in singleton object `Resource` in package `misc`
  and try it out in the REPL

- Use the `nextExercise` command to move to the next exercise.