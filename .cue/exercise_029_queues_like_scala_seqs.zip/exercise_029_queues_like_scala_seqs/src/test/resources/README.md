queues_like_scala_seqs

# Exercise > Queues like Scala Seqs

*Note* this exercise is optional

- Mix `Seq` and `SeqLike` into `Queue`

- Implement the abstract methods `apply`, `length` and `iterator` in terms of
  the wrapped `Seq`

- Look up the exact signature of `newBuilder` in the API docs

- Now the following should be possible:

```scala
     scala> Queue(1, 2, 3) filter (_ > 1)
     res0: misc.Queue[Int] = Queue(2, 3)
```

- But we are not there yet:

```scala
     scala> Queue(1, 2, 3) map (_ + 1)
     res0: Seq[Int] = List(2, 3, 4)
```

- Use the `nextExercise` command to move to the next exercise.
