tail-recursive-operation

# Exercise > Tail recursive operation

- Add an `isIncreasing` method to the `Time` companion object

  - Add a parameter of type immutable `Seq` of `Time`
  - Return true only if the given times are strictly increasing
  - Implement the method in a tail recursive fashion
  - A train's schedule should be strictly increasing in time
    Use `Time.isIncreasing` to assert this requirement
    
**Hints**
  - In general, concentrate on getting a working solution first 
    and **then** try to figure out how to make this solution tail 
    recursive
  - In some cases, a recursive method can be made tail recursive
    **without** having to resort to using an internal method with
    an accumulator
  - You may wish to exploit so-called **short-circuit** evaluation
    of boolean expressions such and AND (&&) or OR (||)
    If you're unfamiliar with this concept, read-up on it at:
    [Short circuit evaluation](https://en.wikipedia.org/wiki/Short-circuit_evaluation) 

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.
