calculate-connections-III

# Exercise > Calculate connections III

- Next create the `Hop` abstract class (add it to `JourneyPlanner.scala`)

  - Add the `from` and `to` class parameters of type `Station`
  - Add a `trainInfo` class parameter of type `TrainInfo`
  - Promote the `from`, `to` and `trainInfo` class parameters
    to fields
  - Make `Hop`'s constructor protected
  - Override `Hop`'s `toString` method to emulate a case class representation
  - Override and define the `equals` and `hashcode` methods to enable
    proper testing for equality between `Hop` instances

  **Hint**: Look at the `##` method defined on `Tuple3` for inspiration
        on defining `hashcode`
        
  - Declare two abstract, immutable fields `departureTime` and `arrivalTime`
    of type `Time`
  
  - Add a `createHop` method to a `Hop` companion object that returns an
    instance of `Hop` and that takes 3 parameters:
      - `from` and `to` of type `Station`
      - `train` of type `Train`
  
  - Add the following checks to `createHop`:
    
    - `from` and `to` stations should be distinct
    - `from` and `to` should be back-to-back stations for the passed-in train
    
  - Override the `departureTime` and `arrivalTime` fields and initialize
    them appropriately

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.  