implicit-parameter-chaining

# Demo > Implicit Parameter Chaining

- In this demo, we will show implicit parameter chaining in action

- To follow along, get the demo source code by entering the following
  command in sbt:

    `pullTemplate scala/com/lightbend/training/scalatrain/ChainingImplicitParameters.scala`

- Use the `nextExercise` command to move to the next exercise.
