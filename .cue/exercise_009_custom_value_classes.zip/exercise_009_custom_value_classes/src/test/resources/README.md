custom-value-classes

# Exercise > Custom Value Classes

- Inspect the byte code of a method with a parameter of type `Station`

- Make `Station` a custom value class

- Inspect the byte code once again and see the difference

**Note**: Class bytecode can be inspected in the REPL by using the `javap` command.
          For this exercise, use `:javap -p <class>`

- Use the `nextExercise` command to move to the next exercise.