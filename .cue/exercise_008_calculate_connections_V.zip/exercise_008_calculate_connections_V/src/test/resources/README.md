calculate-connections-V

# Exercise > Calculate connections V

- Finally add a `connections` method to `JourneyPlanner`

  - Add `from` and `to` parameters of type `Station`, which must 
    not be equal, and a `departureTime` parameter of type `Time`
  - Use a `Set` of immutable `Vector` of `Hop` for the return type
  - Use a recursive algorithm, drop connections starting earlier
    than the given `departureTime` and drop connections where the
    `departureTime` of a subsequent `Hop` is earlier that the
    `arrivalTime` of the current one
  - Drop connections with duplicate `Stations`
  - Hint: Make a drawing with a 'sample' `JourneyPlanner` 
    configuration that has a series of `Stations` and `Trains`. Use
    arrows between stations to depict a hop for a `Train` between
    subsequent `Stations`
  - Hint: Think about the initial step in the process of calculating
    the connections: from a given `from` `Station`, a first, possibly
    empty, series of first `Hops` can be calculated
  - Hint: Given the first `Hops` calculated in the
    previous step, think about how the process of calculating the 
    connections can be carried out in a recursive fashion. Consider 
    a 'divide and conquer' approach.
    

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.
