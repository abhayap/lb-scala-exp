/*
 * Copyright © 2012 - 2017 Lightbend, Inc. All rights reserved.
 */

package misc

import scala.collection.immutable.Seq

object Queue {

  def apply[A](elements: A*): Queue[A] =
    new Queue(elements.toVector)
}

class Queue[A] private (private val elements: Seq[A]) {

  override def equals(other: Any): Boolean =
    other match {
      case that: Queue[_] => (this eq that) || (this.elements == that.elements)
      case _              => false
    }

  override def hashCode: Int =
    elements.hashCode

  override def toString: String =
    s"Queue(${elements mkString ", "})"
}
