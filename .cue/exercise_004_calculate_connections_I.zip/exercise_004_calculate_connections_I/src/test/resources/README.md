calculate-connections-I

# Exercise > Calculate connections I

- This is a multi-step exercise

- The goal is to add a connections method to `JourneyPlanner` calculating
  all connections between two `Station`s

- First add an immutable `backToBackStations` field to `Train`

  - Use an immutable `Seq` of `(Station, Station)` for the type
  - Initialize it with the sequence of all pairs of consecutive
    Stations, e.g. `Seq(a -> b, b -> c)` for `Seq(a, b, c)`
  - Use `zip` instead of sliding

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.