folding

# Exercise > Use foldLeft

- The goal of this exercise is to calculate some basic statistics of an actual
  train journey:
  
  - A train arriving in a station **after** the scheduled time is considered to
    have incurred a **delay**
  - A train arriving in a station **before** the scheduled time is considered to
    have an **early** **arrival** **time**
  - Your task will be to calculate the cummulative **delay** and **early** **arrival** **time**
    
- Create a `TravelStats` case class (add it to `Train.scala`)

  - Add class parameters `totalDelay` and `totalEarlyArrival` of type `Int`
 
- Add a method named `travelStats` to the `Train` class
  
  - Add a parameter of type immutable `Seq[Time]`
    
    - This sequence should have at least two elements.
    - The times in this sequence should be strictly increasing
    - Re-enforce these requirements
    
  - Return a `TravelStats` that contains the cummulative **delay** and 
    **early** **arrival** **time**

  
**Notes** 

- The immutable `Seq[Time]` passed to `travelStats` has the following properties:

  - The first `Time` in the sequence is the departure time in the first `Station`
  - Subsequent `Time`s are arrival times in stations

- Delay and early arrival times are measured in minutes
  
**Hints**

  - think `zip`

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.