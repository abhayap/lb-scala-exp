group-exercise-dsl-for-time

# Exercise > Group exercise: DSL for Time

- Let's create a `DSL` which lets us create `Time`s like this:

```scala
     scala> 11 am
     res0: Time = 11:00

     scala> 11 :: 30
     res1: Time = 11:30

     scala> 11 :: 30 pm
     res2: Time = 23:30
```

**Notes**

  - This exercise asks you to perform a conversion from the 12-hour time
    system to the 24-hour time system

  - The following sample conversion table should help you in case you're
    unfamiliar with the 12-hour system:
    
    01:00am => 01:00    01:00pm => 13:00
    01:05am => 01:05    01:05pm => 13:05
    .
    .
    .
    11:59am => 11:59    11:59pm => 23:59
    12:00am => 00:00    12:00pm => 12:00
    .
    .
    .
    12:59am => 00:59    12:59pm => 12:59
  
  - One of the take-aways is that in the twelve-hour time system, the hour
    value cannot be 0

- Don't change the `Time` class itself, but add the `DSL` as a layer on top 
  of the domain objects

- Hint: All we need are operator notation and implicit conversions

- Use the `nextExercise` command to move to the next exercise.