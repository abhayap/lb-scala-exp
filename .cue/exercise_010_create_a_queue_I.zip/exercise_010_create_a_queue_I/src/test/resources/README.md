create-a-queue-I

# Exercise > Create a queue - I

- The standard library contains a `Queue` class, but we will write our own from
  scratch

- Create the `Queue` class in the misc package

  - Add an `A` type parameter and an `elements` class parameter of type
    immutable `Seq` of `A`
  - Promote class parameter `elements` to a field
  - Hide the implementation details by changing the visibility of the `elements`
    field to `private`
  - Override `equals` and `hashCode` by delegating to `elements`
    - Note that for the `equals` method, you should verify that the object
      you're comparing the current `Queue` to is actually also a `Queue`
      **Hint**: Think pattern matching
  - Override `toString` in case class fashion

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.