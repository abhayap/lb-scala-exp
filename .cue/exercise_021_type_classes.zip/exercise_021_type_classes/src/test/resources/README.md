type-classes

# Exercise > Type classes

- Apply the type class pattern to the `===` operator:

  - Create the `Equal[A]` type class declaring an `equal(a1: A, a2: A): Boolean`
    method
  - Add a type class instance for `Int` behaving as expected
  - Add a type class instance for `String` behaving in an inverted fashion

```scala
     1   === 1      // true, as expected
     "a" === "a"    // false, inverted
```

- Provide an `Equal[Any]` based on natural equality that is used as default:

  - Think about using a default value for a method parameter
  - You may run into an issue with variance that can be solved by
    changing the variance of a type parameter

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.