create-a-queue-III

# Exercise > Create a queue - III

- Add a `dequeue` method to `Queue`

  - Use a `Tuple2` of `A` and `Queue` of `A` for the return type
  - Return the first element and a new `Queue` without the dequeued element
  - Throw an `UnsupportedOperationException` if the Queue is empty

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.