/*
 * Copyright © 2012 - 2017 Lightbend, Inc. All rights reserved.
 */

package com.lightbend.training.scalatrain

class JourneyPlanner(trains: Set[Train]) {

  val stations: Set[Station] =
    trains.flatMap(train => train.stations)

  val hops: Map[Station, Set[Hop]] = {
    val hops = for {
      train <- trains
      (from, to) <- train.backToBackStations
    } yield Hop.createHop(from, to, train)
    hops groupBy (_.from)
  }

  def trainsAt(station: Station): Set[Train] =
    trains.filter(train => train.stations.contains(station))

  def stopsAt(station: Station): Set[(Time, Train)] =
    for {
      train <- trains
      time <- train.timeAt(station)
    } yield (time, train)

  def isShortTrip(from: Station, to: Station): Boolean =
    trains.exists(train =>
      train.stations.dropWhile(station => station != from) match {
        case `from` +: `to` +: _      => true
        case `from` +: _ +: `to` +: _ => true
        case _                        => false
      }
    )
}

object Hop {
  def createHop(from: Station, to: Station, train: Train): Hop = new Hop(from, to, train.info) {
    require(from != to, "From and To stations must be distinct")
    require(train.backToBackStations.contains(from -> to), "From and To stations must be back to back")
    override val departureTime: Time = train.departureTimes(from)
    override val arrivalTime: Time = train.departureTimes(to)
  }
}

abstract class Hop protected (val from: Station, val to: Station, val trainInfo: TrainInfo) {
  val departureTime: Time
  val arrivalTime: Time

  override def toString: String = s"Hop($from, $to, $trainInfo)"

  override def hashCode: Int = (from, to, trainInfo).##

  override def equals(that: Any): Boolean = {
    that match {
      case other: Hop =>
        (from == other.from) &&
          (to == other.to) &&
          (trainInfo == other.trainInfo)
      case _ => false
    }
  }
}
