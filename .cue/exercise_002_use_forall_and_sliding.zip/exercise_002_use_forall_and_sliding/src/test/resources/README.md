use-forall-and-sliding

# Exercise > Use forall and sliding

-  Add an `isIncreasingSliding` method to the `Time` companion object

   - Add a parameter of type immutable `Seq` of `Time`
   - Return true only if the given times are strictly increasing
   - Implement the method using `forall` and `sliding`
   
**Hints**

   - Don't use recursion to solve this exercise
   - You will likely be able to use certain elements from the previous 
     exercise

- Use the `test` command to verify the solution works as expected.

- Compare this implementation to `isIncreasing` implemented recursively: Are 
  there objective pros or cons?

- Use the `nextExercise` command to move to the next exercise.