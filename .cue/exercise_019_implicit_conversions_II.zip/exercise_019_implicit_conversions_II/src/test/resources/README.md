implicit-conversions-II

# Exercise > Implicit Conversions II

- In `ScalaTrain` we also often need `Time`s

- Wouldn't it be nice to use `Strings` like 9:45 instead?

```scala
    ("9:30": Time) - "7:29"
```

- Quiz: Which kinds of implicit conversions are applied here?

- Create an implicit conversion from `String` to `Time`:

- Implement it using regular expressions

- Use the `test` command to verify the solution works as expected.

- Also give it a try in the REPL

- Use the `nextExercise` command to move to the next exercise.
