/*
 * Copyright © 2012 - 2017 Lightbend, Inc. All rights reserved.
 */

package misc

object Equal {

  implicit class EqualOps[A](val a: A) extends AnyVal {

    def ===(a2: A): Boolean =
      a == a2
  }
}
