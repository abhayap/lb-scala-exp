/*
 * Copyright © 2012 - 2017 Lightbend, Inc. All rights reserved.
 */

package misc

import org.scalatest.{ Matchers, NonImplicitAssertions, WordSpec }

class EqualSpec extends WordSpec with Matchers with NonImplicitAssertions {

  import Equal._

  "Calling ===" should {
    "be true for equal objects" in {
      1 === 1 shouldBe true
    }
    "be false for nonequal objects" in {
      1 === 2 shouldBe false
    }
  }
}
